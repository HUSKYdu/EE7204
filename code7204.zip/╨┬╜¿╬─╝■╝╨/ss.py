import skimage.transform as st
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
# 构建测试图片
img= mpimg.imread('./sample.jpg')

image=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
# hough 线变换
h, theta, d = st.hough_line(image)
# 生成一个一行两列的窗口(可显示两张图片).

# 显示原始图片
plt.imshow(image)
plt.show()

# 显示 hough 变换所得数据
#plt.imshow(np.log(1 + h))
#plt.show()
hn=[]
X=[]
for i in range(0,200):
    hn.append(h[i*5])
    X.append(i*5)
plt.imshow(hn)
plt.show()
###################################################################################
Y=[]
for i in range(0,180):
    Y.append(i)

Z=hn

xx, yy = np.meshgrid(X, Y)
X, Y = xx.ravel(), yy.ravel()
bottom = np.zeros_like(X)
Z=np.array(Z)
Z = Z.ravel()

width = height = 1

fig = plt.figure()
ax = fig.gca(projection='3d')
ax.bar3d(X, Y, bottom, width, height, Z, shade=True)  #

ax.set_xlabel('Lenth')
ax.set_ylabel('Theta')
ax.set_zlabel('Number of point')
plt.show()

