import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import cv2
import skimage.transform as st
import sklearn
import cv2
import numpy as np
import matplotlib.pyplot as plt
img= mpimg.imread('./sample.jpg')
plt.imshow(img)
plt.savefig('Original image.svg', type='svg')
plt.show()


img1=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
for i in range(0,len(img1)):
    for j in range(0,len(img1[0])):
        if img1[i][j]>=148:
            img1[i][j]=255
        else:
            img1[i][j]=0
plt.imshow(img1,cmap='gray')
plt.savefig('Gray image_otsu.svg', type='svg')
plt.show()


img=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
img=cv2.equalizeHist(img)

histg=[]

for i in range(0,len(img)):
    for j in range(0,len(img[0])):
        histg.append(img[i][j])
print('gggggggg')
x=[]
for i in range(0,256):
    x.append(i)
plt.figure(figsize=(12,8))
plt.hist(histg,bins=50,color='r')
plt.xlabel('Gray Level')
plt.ylabel('Number of Point')
plt.savefig('Histogram of sample-equalization.svg', type='svg')
plt.show()

plt.imshow(img,cmap='gray')
plt.savefig('figureequa.svg')
plt.show()